package aed.loops;

public class Utils {
  public static int maxNumRepeated(Integer[] a, Integer elem)  {
      // Hay que modificar este metodo
    return 0;  
  }
}
